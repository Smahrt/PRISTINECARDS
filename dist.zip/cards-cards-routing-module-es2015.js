(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["cards-cards-routing-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/idcard/idcard.component.html":
/*!************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/idcard/idcard.component.html ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n  <div class=\"card\">\n    <div class=\"back\">\n      <div class=\"logo\"><span></span></div>\n      <br><br><br>\n      <h4>{{imessage}}<span>design <i>&</i> photography</span></h4>\n    </div>\n\n\n    <div class=\"front\">\n      <div class=\"container\" style=\"padding-bottom:300px; padding-top: 0%;\">\n        <br><br><br>\n        <h4 class=\"ma-5\">{{imessage}}<span>design <i>&</i> photography</span></h4>\n\n      </div><br><br>\n      <ul class=\"padding-top:400px\">\n        <li>AGE:{{imessages}}</li>\n        <li>.{{imessagesss}}</li>\n        <li>BG:{{imessagess}}</li>\n      </ul>\n    </div>\n  </div>\n</div>\n<br><br><br>\n<span>\n  <h6 style=\"color:red\">Move Your Mouse Over The Card To Flip It!</h6>\n</span>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/idform/idform.component.html":
/*!************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/idform/idform.component.html ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class='pr-5 pt-4' style=\"float:right\">\n  <button type=\"button\" *ngIf='!showSingleCard' (click)='showSingleCard=!showSingleCard' class=\"btn btn-warning\">Show\n    Current Card</button>\n</div>\n<div class='pr-5 pt-4' style=\"float:right\">\n  <button type=\"button\" *ngIf='showSingleCard' (click)='showSingleCard=!showSingleCard' class=\"btn btn-warning\">Back To\n    Forms</button>\n</div>\n\n<br><br><br><br>\n\n\n<div class=\"\" *ngIf='!showSingleCard'>\n  <h4 class=\"text-center\">FILL THE FORM BELOW TO CREATE YOUR CUSTOM CARD</h4><br><br>\n\n  <h5 class=\"text-center pb-5\">No Of Cards Created:{{totalIds}}</h5>\n\n\n  <div class=\"container\">\n    <div class=\"row\">\n      <div class=\"col-lg-6\">\n        <div class=\"container\">\n          <form class=\"container shadow\" [formGroup]=\"makeIdFormGroup\" (ngSubmit)=\"makeNewId()\">\n            <div class=\"py-4\" style=\"text-align:center\">\n              <h5>PLEASE FILL IN CARD DETAILS</h5>\n            </div>\n\n            <div class=\"form-group\">\n              <label for=\"exampleInputEmail1\">Full Name</label>\n              <input type=\"text\" class=\"form-control\" formControlName=\"fullname\" id=\"validationDefault01\"\n                aria-describedby=\"emailHelp\" placeholder=\"\">\n                <!-- <small style=\"color:red\" *ngIf='!makeIdFormGroup.valid'>enter full name</small> -->\n            </div>\n            <div class=\"form-group\">\n              <label for=\"exampleInputEmail1\">Age</label>\n              <input type=\"number\" class=\"form-control\" formControlName=\"age\" id=\"exampleInputEmail1\"\n                aria-describedby=\"emailHelp\" placeholder=\"\">\n                <small style=\"color:red\" *ngIf='!makeIdFormGroup.valid'>Numbers only!</small>\n\n            </div>\n            <div class=\"form-group\">\n              <label for=\"exampleInputEmail1\">Blood Group</label>\n              <input type=\"text\" class=\"form-control\" formControlName=\"bloodgroup\" id=\"exampleInputEmail1\"\n                aria-describedby=\"emailHelp\" placeholder=\"eg AA\">\n                <small style=\"color:red\" *ngIf='!makeIdFormGroup.valid'>enter only two letters</small>\n\n            </div>\n            <div class=\"form-group\">\n              <label for=\"exampleInputEmail1\">Location</label>\n              <input type=\"email\" class=\"form-control\" formControlName=\"location\" id=\"exampleInputEmail1\" \n              aria-describedby=\"emailHelp\" placeholder=\"\">\n\n            </div>\n            <div class=\"pr-1\">\n              <button type=\"submit\" [disabled]=\"!makeIdFormGroup.valid\" class=\"btn btn-primary\">Submit</button>\n            </div>\n            <small *ngIf=\"!makeIdFormGroup.valid\">Please fill all details above to create your Id</small>\n            <br>\n\n          </form>\n        </div>\n      </div>\n      \n\n\n      <div class=\"col-lg-2\">\n\n\n        <app-idcard [imessage]=[makeIdFormGroup.value.fullname] [imessages]=[makeIdFormGroup.value.age]\n          [imessagess]=[makeIdFormGroup.value.bloodgroup] [imessagesss]=[makeIdFormGroup.value.location]></app-idcard>\n      </div>\n    </div>\n  </div>\n</div><br>\n<h5 class=\"text-center pb-5\" *ngIf='!showSingleCard'>All CARDS:{{totalIds}}</h5>\n\n\n\n<div class=\"col-lg-4\" id=\"outPopUp\" *ngIf='showSingleCard'>\n  <app-idcard [imessage]=[makeIdFormGroup.value.fullname] [imessages]=[makeIdFormGroup.value.age]\n    [imessagess]=[makeIdFormGroup.value.bloodgroup] [imessagesss]=[makeIdFormGroup.value.location]></app-idcard>\n</div>\n"

/***/ }),

/***/ "./src/app/cards/cards-routing.module.ts":
/*!***********************************************!*\
  !*** ./src/app/cards/cards-routing.module.ts ***!
  \***********************************************/
/*! exports provided: CardsRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CardsRoutingModule", function() { return CardsRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _app_idcard_idcard_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @app/idcard/idcard.component */ "./src/app/idcard/idcard.component.ts");
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../_helpers */ "./src/app/_helpers/index.ts");
/* harmony import */ var _idform_idform_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../idform/idform.component */ "./src/app/idform/idform.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");





// import { IdformComponent } from "@app/idform/idform.component";



const routes = [{ path: "", component: _idform_idform_component__WEBPACK_IMPORTED_MODULE_5__["IdformComponent"], canActivate: [_helpers__WEBPACK_IMPORTED_MODULE_4__["AuthGuard"]] }];
// @NgModule({
//   imports: [IdformComponent, RouterModule.forChild(routes)],
//   declarations: [IdformComponent],
//   exports: [IdformComponent, RouterModule]
// })
let CardsRoutingModule = class CardsRoutingModule {
};
CardsRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ReactiveFormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)
        ],
        declarations: [_idform_idform_component__WEBPACK_IMPORTED_MODULE_5__["IdformComponent"], _app_idcard_idcard_component__WEBPACK_IMPORTED_MODULE_3__["IdcardComponent"]],
        exports: [_idform_idform_component__WEBPACK_IMPORTED_MODULE_5__["IdformComponent"], _app_idcard_idcard_component__WEBPACK_IMPORTED_MODULE_3__["IdcardComponent"]]
    })
], CardsRoutingModule);



/***/ }),

/***/ "./src/app/idcard/idcard.component.css":
/*!*********************************************!*\
  !*** ./src/app/idcard/idcard.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "*{box-sizing:border-box}\r\nbody {\r\n  margin: 0;\r\n  background: #1C1A30;\r\n  height: 100vh;\r\n  display: flex;\r\n  align-items: center;\r\n}\r\n.container {\r\n  width: 500px;\r\n  height: 260px;\r\n  margin: 0 auto;\r\n  position: relative;\r\n  -webkit-perspective: 1000;\r\n\tperspective: 1000;\r\n  -moz-transform: perspective(1400px);\r\n\t-ms-transform: perspective(1400px);\r\n\t-webkit-transform-style: preserve-3d;\r\n  transform-style: preserve-3d;\r\n  -webkit-perspective-origin: right;\r\n  perspective-origin: right;\r\n}\r\n.card {\r\n  width: 500px;\r\n  height: 260px;\r\n  box-shadow: 0 27px 55px 0 rgba(0, 0, 0, .7), 0 17px 17px 0 rgba(0, 0, 0, .5);\r\n  position: relative;\r\n  -webkit-transform: rotate(0deg);\r\n  transform: rotate(0deg);\r\n  -webkit-transform-origin: 100% 0%;\r\n  transform-origin: 100% 0%;\r\n  -webkit-transform-style: preserve-3d;\r\n  transform-style: preserve-3d;\r\n  transition: .8s ease-in-out;\r\n}\r\n.logo {\r\n  width: 50px;\r\n  height: 50px;\r\n  position: relative;\r\n  background:\r\n  linear-gradient(45deg, #F5AF69 50%, #F4EED7 50.9%),\r\n  linear-gradient(90deg, #FC5135 50%, #4E203C 50%),\r\n  linear-gradient(-45deg, #F5AF69 50%, #E8D9A0 50.9%),\r\n  linear-gradient(#FC5135 50%, #4E203C 50%),\r\n  linear-gradient(-45deg, #F5AF69 50%, #E8D9A0 50.9%),\r\n  linear-gradient(90deg, #FC5135 50%, #4E203C 50%),\r\n  linear-gradient(45deg, #FC5135 50%, #F5AF69 50.9%);\r\n  background-size: 50px 50px, 100px 50px, 50px 50px, 200px 100px, 50px 50px, 100px 50px, 50px 50px;\r\n  background-repeat: no-repeat;\r\n  background-position: 0 0, 50px 0px, 150px 0, 0 50px, 0 150px, 50px 150px, 150px 150px;\r\n}\r\n.logo:before {\r\n  content: \"\";\r\n  position: absolute;\r\n  top: 10px;\r\n  left: 10px;\r\n  width: 30px;\r\n  height: 30px;\r\n  -webkit-transform: rotate(45deg);\r\n  transform: rotate(45deg);\r\n  background: linear-gradient(45deg, #F4EED7 50%, #E8D9A0 50%);\r\n}\r\n.logo:after {\r\n  content: \"\";\r\n  position: absolute;\r\n  top: 15px;\r\n  left: 15px;\r\n  width: 30px;\r\n  height: 30px;\r\n  -webkit-transform: rotate(45deg);\r\n  transform: rotate(45deg);\r\n  background: linear-gradient(45deg, #FC5135 50%, #4E203C 49.9%),\r\n  linear-gradient(-45deg, #F5AF69 50%, transparent 50%),\r\n  linear-gradient(#FC5135 50%, #FC5135 50%),\r\n  linear-gradient(-45deg, #4E203C 50%, transparent 50%);\r\n  background-size: 45px 45px;\r\n  background-repeat: no-repeat;\r\n  background-position: 0 0, 0 45px, 45px 45px, 45px 0;\r\n  border-radius: 0 50% 50% 50%;\r\n}\r\n.logofront {\r\n  width: 50px;\r\n  height: 50px;\r\n  position: relative;\r\n  background:\r\n  linear-gradient(45deg, #F5AF69 50%, #F4EED7 50.9%),\r\n  linear-gradient(90deg, #FC5135 50%, #4E203C 50%),\r\n  linear-gradient(-45deg, #F5AF69 50%, #E8D9A0 50.9%),\r\n  linear-gradient(#FC5135 50%, #4E203C 50%),\r\n  linear-gradient(-45deg, #F5AF69 50%, #E8D9A0 50.9%),\r\n  linear-gradient(90deg, #FC5135 50%, #4E203C 50%),\r\n  linear-gradient(45deg, #FC5135 50%, #F5AF69 50.9%);\r\n  background-size: 50px 50px, 100px 50px, 50px 50px, 200px 100px, 50px 50px, 100px 50px, 50px 50px;\r\n  background-repeat: no-repeat;\r\n  background-position: 0 0, 50px 0px, 150px 0, 0 50px, 0 150px, 50px 150px, 150px 150px;\r\n}\r\n.logofront:before {\r\n  content: \"\";\r\n  position: absolute;\r\n  /* top: 10px; */\r\n  /* left: 10px; */\r\n  width: 30px;\r\n  height: 30px;\r\n  -webkit-transform: rotate(45deg);\r\n  transform: rotate(45deg);\r\n  background: linear-gradient(45deg, #F4EED7 50%, #E8D9A0 50%);\r\n}\r\n.logofront:after {\r\n  content: \"\";\r\n  position: absolute;\r\n  /* top: 10px; */\r\n  /* left: 10px; */\r\n  width: 30px;\r\n  height: 30px;\r\n  -webkit-transform: rotate(45deg);\r\n  transform: rotate(45deg);\r\n  background: linear-gradient(45deg, #FC5135 50%, #4E203C 49.9%),\r\n  linear-gradient(-45deg, #F5AF69 50%, transparent 50%),\r\n  linear-gradient(#FC5135 50%, #FC5135 50%),\r\n  linear-gradient(-45deg, #4E203C 50%, transparent 50%);\r\n  background-size: 45px 45px;\r\n  background-repeat: no-repeat;\r\n  background-position: 0 0, 0 45px, 45px 45px, 45px 0;\r\n  border-radius: 0 50% 50% 50%;\r\n}\r\n/* .logo span {\r\n  display: block;\r\n  background: #4E203C;\r\n  width: 9px;\r\n  height: 9px;\r\n  position: absolute;\r\n  top: 99.5px;\r\n  left: 130px;\r\n  border-radius: 0 50% 50% 0;\r\n}\r\n .logo span:before {\r\n  content: \"\";\r\n  width: 10px;\r\n  height: 10px;\r\n  background: #E8D9A0;\r\n  border-radius: 50%;\r\n  position: absolute;\r\n  top: 11px;\r\n  left: 10px;\r\n  z-index: 2;\r\n} */\r\n.front, .back {\r\n  position: absolute;\r\n  top: 0;\r\n  left: 0;\r\n  width: 100%;\r\n  height: 100%;\r\n  background: white;\r\n  -webkit-backface-visibility: hidden;\r\n  backface-visibility: hidden;\r\n}\r\n.front {\r\n  display: flex;\r\n  justify-content: center;\r\n  align-items: center;\r\n  z-index: 2;\r\n  -webkit-transform: rotateY(0deg);\r\n  transform: rotateY(0deg);\r\n}\r\n.back {\r\n  -webkit-transform: rotateY(-180deg);\r\n  transform: rotateY(-180deg);\r\n  font-family: 'Arimo', sans-serif;\r\n}\r\n.container:hover .card {\r\n  -webkit-transform: rotateY(180deg) translateX(100%);\r\n  transform: rotateY(180deg) translateX(100%);\r\n  cursor: pointer;\r\n}\r\nul {\r\n  margin: 0;\r\n  width: 100%;\r\n  list-style: none;\r\n  position: absolute;\r\n  bottom: 30px;\r\n  left: 0;\r\n  padding: 0 1%;\r\n}\r\nul:after {\r\n  content: '';\r\n  display: table;\r\n  clear: both;\r\n}\r\nli {\r\n  width: 31.3333333333%;\r\n  margin: 0 1%;\r\n  float: left;\r\n  padding: 10px;\r\n  border: 2px solid #FC5135;\r\n  border-radius: 4px;\r\n  position: relative;\r\n  text-align: center;\r\n  color: #4E203C;\r\n}\r\nli:before {\r\n  position: absolute;\r\n  top: -25px;\r\n  left: 50%;\r\n  margin-left: -15px;\r\n  width: 30px;\r\n  height:30px;\r\n  background: #FC5135;\r\n  color: white;\r\n  line-height: 30px;\r\n  text-align: center;\r\n  border-radius: 50%;\r\n  font-family: FontAwesome;\r\n}\r\nli:nth-child(1):before {content: \"\\f095\"}\r\nli:nth-child(2):before {content: \"\\f003\"}\r\nli:nth-child(3):before {content: \"\\f0c1\"}\r\nh4 {\r\n  color: #FC5135;\r\n  text-transform: uppercase;\r\n  /* font-weight: 400; */\r\n  line-height: 1;\r\n  /* margin-top: 10px; */\r\n  text-align: center;\r\n  font-size: 30px;\r\n}\r\nh4 span {\r\n  color: #4E203C;\r\n  display: block;\r\n  font-size: .22em;\r\n  letter-spacing: 3px;\r\n}\r\nh4 i {\r\n  font-style: normal;\r\n  text-transform: none;\r\n  font-family: 'Playfair Display', serif;\r\n}\r\n\r\n\r\n\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaWRjYXJkL2lkY2FyZC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLEVBQUUscUJBQXFCO0FBQ3ZCO0VBQ0UsU0FBUztFQUNULG1CQUFtQjtFQUNuQixhQUFhO0VBRWIsYUFBYTtFQUViLG1CQUFtQjtBQUNyQjtBQUNBO0VBQ0UsWUFBWTtFQUNaLGFBQWE7RUFDYixjQUFjO0VBQ2Qsa0JBQWtCO0VBQ2xCLHlCQUF5QjtDQUUxQixpQkFBaUI7RUFDaEIsbUNBQW1DO0NBQ3BDLGtDQUFrQztDQUNsQyxvQ0FBb0M7RUFFbkMsNEJBQTRCO0VBQzVCLGlDQUFpQztFQUVqQyx5QkFBeUI7QUFDM0I7QUFDQTtFQUNFLFlBQVk7RUFDWixhQUFhO0VBQ2IsNEVBQTRFO0VBQzVFLGtCQUFrQjtFQUNsQiwrQkFBK0I7RUFHL0IsdUJBQXVCO0VBQ3ZCLGlDQUFpQztFQUdqQyx5QkFBeUI7RUFDekIsb0NBQW9DO0VBRXBDLDRCQUE0QjtFQUM1QiwyQkFBMkI7QUFDN0I7QUFDQTtFQUNFLFdBQVc7RUFDWCxZQUFZO0VBQ1osa0JBQWtCO0VBQ2xCOzs7Ozs7O29EQU9rRDtFQUNsRCxnR0FBZ0c7RUFDaEcsNEJBQTRCO0VBQzVCLHFGQUFxRjtBQUN2RjtBQUNDO0VBQ0MsV0FBVztFQUNYLGtCQUFrQjtFQUNsQixTQUFTO0VBQ1QsVUFBVTtFQUNWLFdBQVc7RUFDWCxZQUFZO0VBQ1osZ0NBQWdDO0VBR2hDLHdCQUF3QjtFQUN4Qiw0REFBNEQ7QUFDOUQ7QUFDQTtFQUNFLFdBQVc7RUFDWCxrQkFBa0I7RUFDbEIsU0FBUztFQUNULFVBQVU7RUFDVixXQUFXO0VBQ1gsWUFBWTtFQUNaLGdDQUFnQztFQUdoQyx3QkFBd0I7RUFDeEI7Ozt1REFHcUQ7RUFDckQsMEJBQTBCO0VBQzFCLDRCQUE0QjtFQUM1QixtREFBbUQ7RUFDbkQsNEJBQTRCO0FBQzlCO0FBRUE7RUFDRSxXQUFXO0VBQ1gsWUFBWTtFQUNaLGtCQUFrQjtFQUNsQjs7Ozs7OztvREFPa0Q7RUFDbEQsZ0dBQWdHO0VBQ2hHLDRCQUE0QjtFQUM1QixxRkFBcUY7QUFDdkY7QUFDQztFQUNDLFdBQVc7RUFDWCxrQkFBa0I7RUFDbEIsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixXQUFXO0VBQ1gsWUFBWTtFQUNaLGdDQUFnQztFQUdoQyx3QkFBd0I7RUFDeEIsNERBQTREO0FBQzlEO0FBQ0E7RUFDRSxXQUFXO0VBQ1gsa0JBQWtCO0VBQ2xCLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsV0FBVztFQUNYLFlBQVk7RUFDWixnQ0FBZ0M7RUFHaEMsd0JBQXdCO0VBQ3hCOzs7dURBR3FEO0VBQ3JELDBCQUEwQjtFQUMxQiw0QkFBNEI7RUFDNUIsbURBQW1EO0VBQ25ELDRCQUE0QjtBQUM5QjtBQUtDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQW9CRTtBQUNIO0VBQ0Usa0JBQWtCO0VBQ2xCLE1BQU07RUFDTixPQUFPO0VBQ1AsV0FBVztFQUNYLFlBQVk7RUFDWixpQkFBaUI7RUFDakIsbUNBQW1DO0VBRW5DLDJCQUEyQjtBQUM3QjtBQUNBO0VBRUUsYUFBYTtFQUViLHVCQUF1QjtFQUV2QixtQkFBbUI7RUFDbkIsVUFBVTtFQUNWLGdDQUFnQztFQUdoQyx3QkFBd0I7QUFDMUI7QUFDQTtFQUNFLG1DQUFtQztFQUduQywyQkFBMkI7RUFDM0IsZ0NBQWdDO0FBQ2xDO0FBQ0E7RUFDRSxtREFBbUQ7RUFHbkQsMkNBQTJDO0VBQzNDLGVBQWU7QUFDakI7QUFDQTtFQUNFLFNBQVM7RUFDVCxXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixZQUFZO0VBQ1osT0FBTztFQUNQLGFBQWE7QUFDZjtBQUNBO0VBQ0UsV0FBVztFQUNYLGNBQWM7RUFDZCxXQUFXO0FBQ2I7QUFDQTtFQUNFLHFCQUFxQjtFQUNyQixZQUFZO0VBQ1osV0FBVztFQUNYLGFBQWE7RUFDYix5QkFBeUI7RUFDekIsa0JBQWtCO0VBQ2xCLGtCQUFrQjtFQUNsQixrQkFBa0I7RUFDbEIsY0FBYztBQUNoQjtBQUNBO0VBQ0Usa0JBQWtCO0VBQ2xCLFVBQVU7RUFDVixTQUFTO0VBQ1Qsa0JBQWtCO0VBQ2xCLFdBQVc7RUFDWCxXQUFXO0VBQ1gsbUJBQW1CO0VBQ25CLFlBQVk7RUFDWixpQkFBaUI7RUFDakIsa0JBQWtCO0VBQ2xCLGtCQUFrQjtFQUNsQix3QkFBd0I7QUFDMUI7QUFDQSx3QkFBd0IsZ0JBQWdCO0FBQ3hDLHdCQUF3QixnQkFBZ0I7QUFDeEMsd0JBQXdCLGdCQUFnQjtBQUN4QztFQUNFLGNBQWM7RUFDZCx5QkFBeUI7RUFDekIsc0JBQXNCO0VBQ3RCLGNBQWM7RUFDZCxzQkFBc0I7RUFDdEIsa0JBQWtCO0VBQ2xCLGVBQWU7QUFDakI7QUFDQTtFQUNFLGNBQWM7RUFDZCxjQUFjO0VBQ2QsZ0JBQWdCO0VBQ2hCLG1CQUFtQjtBQUNyQjtBQUNBO0VBQ0Usa0JBQWtCO0VBQ2xCLG9CQUFvQjtFQUNwQixzQ0FBc0M7QUFDeEMiLCJmaWxlIjoic3JjL2FwcC9pZGNhcmQvaWRjYXJkLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIqe2JveC1zaXppbmc6Ym9yZGVyLWJveH1cclxuYm9keSB7XHJcbiAgbWFyZ2luOiAwO1xyXG4gIGJhY2tncm91bmQ6ICMxQzFBMzA7XHJcbiAgaGVpZ2h0OiAxMDB2aDtcclxuICBkaXNwbGF5OiAtd2Via2l0LWZsZXg7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICAtd2Via2l0LWFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG4uY29udGFpbmVyIHtcclxuICB3aWR0aDogNTAwcHg7XHJcbiAgaGVpZ2h0OiAyNjBweDtcclxuICBtYXJnaW46IDAgYXV0bztcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgLXdlYmtpdC1wZXJzcGVjdGl2ZTogMTAwMDtcclxuXHQtbW96LXBlcnNwZWN0aXZlOiAxMDAwO1xyXG5cdHBlcnNwZWN0aXZlOiAxMDAwO1xyXG4gIC1tb3otdHJhbnNmb3JtOiBwZXJzcGVjdGl2ZSgxNDAwcHgpO1xyXG5cdC1tcy10cmFuc2Zvcm06IHBlcnNwZWN0aXZlKDE0MDBweCk7XHJcblx0LXdlYmtpdC10cmFuc2Zvcm0tc3R5bGU6IHByZXNlcnZlLTNkO1xyXG4gIC1tb3otdHJhbnNmb3JtLXN0eWxlOiBwcmVzZXJ2ZS0zZDtcclxuICB0cmFuc2Zvcm0tc3R5bGU6IHByZXNlcnZlLTNkO1xyXG4gIC13ZWJraXQtcGVyc3BlY3RpdmUtb3JpZ2luOiByaWdodDtcclxuICAtbW96LXBlcnNwZWN0aXZlLW9yaWdpbjogcmlnaHQ7XHJcbiAgcGVyc3BlY3RpdmUtb3JpZ2luOiByaWdodDtcclxufVxyXG4uY2FyZCB7XHJcbiAgd2lkdGg6IDUwMHB4O1xyXG4gIGhlaWdodDogMjYwcHg7XHJcbiAgYm94LXNoYWRvdzogMCAyN3B4IDU1cHggMCByZ2JhKDAsIDAsIDAsIC43KSwgMCAxN3B4IDE3cHggMCByZ2JhKDAsIDAsIDAsIC41KTtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTtcclxuICAtbW96LXRyYW5zZm9ybTogcm90YXRlKDBkZWcpO1xyXG4gIC1tcy10cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTtcclxuICB0cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTtcclxuICAtd2Via2l0LXRyYW5zZm9ybS1vcmlnaW46IDEwMCUgMCU7XHJcbiAgLW1vei10cmFuc2Zvcm0tb3JpZ2luOiAxMDAlIDAlO1xyXG4gIC1tcy10cmFuc2Zvcm0tb3JpZ2luOiAxMDAlIDAlO1xyXG4gIHRyYW5zZm9ybS1vcmlnaW46IDEwMCUgMCU7XHJcbiAgLXdlYmtpdC10cmFuc2Zvcm0tc3R5bGU6IHByZXNlcnZlLTNkO1xyXG4gIC1tb3otdHJhbnNmb3JtLXN0eWxlOiBwcmVzZXJ2ZS0zZDtcclxuICB0cmFuc2Zvcm0tc3R5bGU6IHByZXNlcnZlLTNkO1xyXG4gIHRyYW5zaXRpb246IC44cyBlYXNlLWluLW91dDtcclxufVxyXG4ubG9nbyB7XHJcbiAgd2lkdGg6IDUwcHg7XHJcbiAgaGVpZ2h0OiA1MHB4O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBiYWNrZ3JvdW5kOlxyXG4gIGxpbmVhci1ncmFkaWVudCg0NWRlZywgI0Y1QUY2OSA1MCUsICNGNEVFRDcgNTAuOSUpLFxyXG4gIGxpbmVhci1ncmFkaWVudCg5MGRlZywgI0ZDNTEzNSA1MCUsICM0RTIwM0MgNTAlKSxcclxuICBsaW5lYXItZ3JhZGllbnQoLTQ1ZGVnLCAjRjVBRjY5IDUwJSwgI0U4RDlBMCA1MC45JSksXHJcbiAgbGluZWFyLWdyYWRpZW50KCNGQzUxMzUgNTAlLCAjNEUyMDNDIDUwJSksXHJcbiAgbGluZWFyLWdyYWRpZW50KC00NWRlZywgI0Y1QUY2OSA1MCUsICNFOEQ5QTAgNTAuOSUpLFxyXG4gIGxpbmVhci1ncmFkaWVudCg5MGRlZywgI0ZDNTEzNSA1MCUsICM0RTIwM0MgNTAlKSxcclxuICBsaW5lYXItZ3JhZGllbnQoNDVkZWcsICNGQzUxMzUgNTAlLCAjRjVBRjY5IDUwLjklKTtcclxuICBiYWNrZ3JvdW5kLXNpemU6IDUwcHggNTBweCwgMTAwcHggNTBweCwgNTBweCA1MHB4LCAyMDBweCAxMDBweCwgNTBweCA1MHB4LCAxMDBweCA1MHB4LCA1MHB4IDUwcHg7XHJcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiAwIDAsIDUwcHggMHB4LCAxNTBweCAwLCAwIDUwcHgsIDAgMTUwcHgsIDUwcHggMTUwcHgsIDE1MHB4IDE1MHB4O1xyXG59XHJcbiAubG9nbzpiZWZvcmUge1xyXG4gIGNvbnRlbnQ6IFwiXCI7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDogMTBweDtcclxuICBsZWZ0OiAxMHB4O1xyXG4gIHdpZHRoOiAzMHB4O1xyXG4gIGhlaWdodDogMzBweDtcclxuICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcclxuICAtbW96LXRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcclxuICAtbXMtdHJhbnNmb3JtOiByb3RhdGUoNDVkZWcpO1xyXG4gIHRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcclxuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoNDVkZWcsICNGNEVFRDcgNTAlLCAjRThEOUEwIDUwJSk7XHJcbn1cclxuLmxvZ286YWZ0ZXIge1xyXG4gIGNvbnRlbnQ6IFwiXCI7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDogMTVweDtcclxuICBsZWZ0OiAxNXB4O1xyXG4gIHdpZHRoOiAzMHB4O1xyXG4gIGhlaWdodDogMzBweDtcclxuICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcclxuICAtbW96LXRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcclxuICAtbXMtdHJhbnNmb3JtOiByb3RhdGUoNDVkZWcpO1xyXG4gIHRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcclxuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoNDVkZWcsICNGQzUxMzUgNTAlLCAjNEUyMDNDIDQ5LjklKSxcclxuICBsaW5lYXItZ3JhZGllbnQoLTQ1ZGVnLCAjRjVBRjY5IDUwJSwgdHJhbnNwYXJlbnQgNTAlKSxcclxuICBsaW5lYXItZ3JhZGllbnQoI0ZDNTEzNSA1MCUsICNGQzUxMzUgNTAlKSxcclxuICBsaW5lYXItZ3JhZGllbnQoLTQ1ZGVnLCAjNEUyMDNDIDUwJSwgdHJhbnNwYXJlbnQgNTAlKTtcclxuICBiYWNrZ3JvdW5kLXNpemU6IDQ1cHggNDVweDtcclxuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gIGJhY2tncm91bmQtcG9zaXRpb246IDAgMCwgMCA0NXB4LCA0NXB4IDQ1cHgsIDQ1cHggMDtcclxuICBib3JkZXItcmFkaXVzOiAwIDUwJSA1MCUgNTAlO1xyXG59XHJcblxyXG4ubG9nb2Zyb250IHtcclxuICB3aWR0aDogNTBweDtcclxuICBoZWlnaHQ6IDUwcHg7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIGJhY2tncm91bmQ6XHJcbiAgbGluZWFyLWdyYWRpZW50KDQ1ZGVnLCAjRjVBRjY5IDUwJSwgI0Y0RUVENyA1MC45JSksXHJcbiAgbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjRkM1MTM1IDUwJSwgIzRFMjAzQyA1MCUpLFxyXG4gIGxpbmVhci1ncmFkaWVudCgtNDVkZWcsICNGNUFGNjkgNTAlLCAjRThEOUEwIDUwLjklKSxcclxuICBsaW5lYXItZ3JhZGllbnQoI0ZDNTEzNSA1MCUsICM0RTIwM0MgNTAlKSxcclxuICBsaW5lYXItZ3JhZGllbnQoLTQ1ZGVnLCAjRjVBRjY5IDUwJSwgI0U4RDlBMCA1MC45JSksXHJcbiAgbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjRkM1MTM1IDUwJSwgIzRFMjAzQyA1MCUpLFxyXG4gIGxpbmVhci1ncmFkaWVudCg0NWRlZywgI0ZDNTEzNSA1MCUsICNGNUFGNjkgNTAuOSUpO1xyXG4gIGJhY2tncm91bmQtc2l6ZTogNTBweCA1MHB4LCAxMDBweCA1MHB4LCA1MHB4IDUwcHgsIDIwMHB4IDEwMHB4LCA1MHB4IDUwcHgsIDEwMHB4IDUwcHgsIDUwcHggNTBweDtcclxuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gIGJhY2tncm91bmQtcG9zaXRpb246IDAgMCwgNTBweCAwcHgsIDE1MHB4IDAsIDAgNTBweCwgMCAxNTBweCwgNTBweCAxNTBweCwgMTUwcHggMTUwcHg7XHJcbn1cclxuIC5sb2dvZnJvbnQ6YmVmb3JlIHtcclxuICBjb250ZW50OiBcIlwiO1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAvKiB0b3A6IDEwcHg7ICovXHJcbiAgLyogbGVmdDogMTBweDsgKi9cclxuICB3aWR0aDogMzBweDtcclxuICBoZWlnaHQ6IDMwcHg7XHJcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZSg0NWRlZyk7XHJcbiAgLW1vei10cmFuc2Zvcm06IHJvdGF0ZSg0NWRlZyk7XHJcbiAgLW1zLXRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcclxuICB0cmFuc2Zvcm06IHJvdGF0ZSg0NWRlZyk7XHJcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDQ1ZGVnLCAjRjRFRUQ3IDUwJSwgI0U4RDlBMCA1MCUpO1xyXG59XHJcbi5sb2dvZnJvbnQ6YWZ0ZXIge1xyXG4gIGNvbnRlbnQ6IFwiXCI7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIC8qIHRvcDogMTBweDsgKi9cclxuICAvKiBsZWZ0OiAxMHB4OyAqL1xyXG4gIHdpZHRoOiAzMHB4O1xyXG4gIGhlaWdodDogMzBweDtcclxuICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcclxuICAtbW96LXRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcclxuICAtbXMtdHJhbnNmb3JtOiByb3RhdGUoNDVkZWcpO1xyXG4gIHRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcclxuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoNDVkZWcsICNGQzUxMzUgNTAlLCAjNEUyMDNDIDQ5LjklKSxcclxuICBsaW5lYXItZ3JhZGllbnQoLTQ1ZGVnLCAjRjVBRjY5IDUwJSwgdHJhbnNwYXJlbnQgNTAlKSxcclxuICBsaW5lYXItZ3JhZGllbnQoI0ZDNTEzNSA1MCUsICNGQzUxMzUgNTAlKSxcclxuICBsaW5lYXItZ3JhZGllbnQoLTQ1ZGVnLCAjNEUyMDNDIDUwJSwgdHJhbnNwYXJlbnQgNTAlKTtcclxuICBiYWNrZ3JvdW5kLXNpemU6IDQ1cHggNDVweDtcclxuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gIGJhY2tncm91bmQtcG9zaXRpb246IDAgMCwgMCA0NXB4LCA0NXB4IDQ1cHgsIDQ1cHggMDtcclxuICBib3JkZXItcmFkaXVzOiAwIDUwJSA1MCUgNTAlO1xyXG59XHJcblxyXG5cclxuXHJcblxyXG4gLyogLmxvZ28gc3BhbiB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgYmFja2dyb3VuZDogIzRFMjAzQztcclxuICB3aWR0aDogOXB4O1xyXG4gIGhlaWdodDogOXB4O1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB0b3A6IDk5LjVweDtcclxuICBsZWZ0OiAxMzBweDtcclxuICBib3JkZXItcmFkaXVzOiAwIDUwJSA1MCUgMDtcclxufVxyXG4gLmxvZ28gc3BhbjpiZWZvcmUge1xyXG4gIGNvbnRlbnQ6IFwiXCI7XHJcbiAgd2lkdGg6IDEwcHg7XHJcbiAgaGVpZ2h0OiAxMHB4O1xyXG4gIGJhY2tncm91bmQ6ICNFOEQ5QTA7XHJcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB0b3A6IDExcHg7XHJcbiAgbGVmdDogMTBweDtcclxuICB6LWluZGV4OiAyO1xyXG59ICovXHJcbi5mcm9udCwgLmJhY2sge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB0b3A6IDA7XHJcbiAgbGVmdDogMDtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgLXdlYmtpdC1iYWNrZmFjZS12aXNpYmlsaXR5OiBoaWRkZW47XHJcbiAgLW1vei1iYWNrZmFjZS12aXNpYmlsaXR5OiBoaWRkZW47XHJcbiAgYmFja2ZhY2UtdmlzaWJpbGl0eTogaGlkZGVuO1xyXG59XHJcbi5mcm9udCB7XHJcbiAgZGlzcGxheTotd2Via2l0LWZsZXg7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICAtd2Via2l0LWp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIC13ZWJraXQtYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIHotaW5kZXg6IDI7XHJcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZVkoMGRlZyk7XHJcbiAgLW1vei10cmFuc2Zvcm06IHJvdGF0ZVkoMGRlZyk7XHJcbiAgLW1zLXRyYW5zZm9ybTogcm90YXRlWSgwZGVnKTtcclxuICB0cmFuc2Zvcm06IHJvdGF0ZVkoMGRlZyk7XHJcbn1cclxuLmJhY2sge1xyXG4gIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGVZKC0xODBkZWcpO1xyXG4gIC1tb3otdHJhbnNmb3JtOiByb3RhdGVZKC0xODBkZWcpO1xyXG4gIC1tcy10cmFuc2Zvcm06IHJvdGF0ZVkoLTE4MGRlZyk7XHJcbiAgdHJhbnNmb3JtOiByb3RhdGVZKC0xODBkZWcpO1xyXG4gIGZvbnQtZmFtaWx5OiAnQXJpbW8nLCBzYW5zLXNlcmlmO1xyXG59XHJcbi5jb250YWluZXI6aG92ZXIgLmNhcmQge1xyXG4gIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGVZKDE4MGRlZykgdHJhbnNsYXRlWCgxMDAlKTtcclxuICAtbW96LXRyYW5zZm9ybTogcm90YXRlWSgxODBkZWcpIHRyYW5zbGF0ZVgoMTAwJSk7XHJcbiAgLW1zLXRyYW5zZm9ybTogcm90YXRlWSgxODBkZWcpIHRyYW5zbGF0ZVgoMTAwJSk7XHJcbiAgdHJhbnNmb3JtOiByb3RhdGVZKDE4MGRlZykgdHJhbnNsYXRlWCgxMDAlKTtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxudWwge1xyXG4gIG1hcmdpbjogMDtcclxuICB3aWR0aDogMTAwJTtcclxuICBsaXN0LXN0eWxlOiBub25lO1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICBib3R0b206IDMwcHg7XHJcbiAgbGVmdDogMDtcclxuICBwYWRkaW5nOiAwIDElO1xyXG59XHJcbnVsOmFmdGVyIHtcclxuICBjb250ZW50OiAnJztcclxuICBkaXNwbGF5OiB0YWJsZTtcclxuICBjbGVhcjogYm90aDtcclxufVxyXG5saSB7XHJcbiAgd2lkdGg6IDMxLjMzMzMzMzMzMzMlO1xyXG4gIG1hcmdpbjogMCAxJTtcclxuICBmbG9hdDogbGVmdDtcclxuICBwYWRkaW5nOiAxMHB4O1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkICNGQzUxMzU7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgY29sb3I6ICM0RTIwM0M7XHJcbn1cclxubGk6YmVmb3JlIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAtMjVweDtcclxuICBsZWZ0OiA1MCU7XHJcbiAgbWFyZ2luLWxlZnQ6IC0xNXB4O1xyXG4gIHdpZHRoOiAzMHB4O1xyXG4gIGhlaWdodDozMHB4O1xyXG4gIGJhY2tncm91bmQ6ICNGQzUxMzU7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIGxpbmUtaGVpZ2h0OiAzMHB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgZm9udC1mYW1pbHk6IEZvbnRBd2Vzb21lO1xyXG59XHJcbmxpOm50aC1jaGlsZCgxKTpiZWZvcmUge2NvbnRlbnQ6IFwiXFxmMDk1XCJ9XHJcbmxpOm50aC1jaGlsZCgyKTpiZWZvcmUge2NvbnRlbnQ6IFwiXFxmMDAzXCJ9XHJcbmxpOm50aC1jaGlsZCgzKTpiZWZvcmUge2NvbnRlbnQ6IFwiXFxmMGMxXCJ9XHJcbmg0IHtcclxuICBjb2xvcjogI0ZDNTEzNTtcclxuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gIC8qIGZvbnQtd2VpZ2h0OiA0MDA7ICovXHJcbiAgbGluZS1oZWlnaHQ6IDE7XHJcbiAgLyogbWFyZ2luLXRvcDogMTBweDsgKi9cclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgZm9udC1zaXplOiAzMHB4O1xyXG59XHJcbmg0IHNwYW4ge1xyXG4gIGNvbG9yOiAjNEUyMDNDO1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIGZvbnQtc2l6ZTogLjIyZW07XHJcbiAgbGV0dGVyLXNwYWNpbmc6IDNweDtcclxufVxyXG5oNCBpIHtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XHJcbiAgZm9udC1mYW1pbHk6ICdQbGF5ZmFpciBEaXNwbGF5Jywgc2VyaWY7XHJcbn1cclxuXHJcblxyXG5cclxuIl19 */"

/***/ }),

/***/ "./src/app/idcard/idcard.component.ts":
/*!********************************************!*\
  !*** ./src/app/idcard/idcard.component.ts ***!
  \********************************************/
/*! exports provided: IdcardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IdcardComponent", function() { return IdcardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../data.service */ "./src/app/data.service.ts");



let IdcardComponent = class IdcardComponent {
    constructor(data) {
        this.data = data;
    }
    ngOnInit() {
        this.data.currentMessage.subscribe(message => this.message = message);
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], IdcardComponent.prototype, "imessage", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], IdcardComponent.prototype, "imessages", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], IdcardComponent.prototype, "imessagess", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], IdcardComponent.prototype, "imessagesss", void 0);
IdcardComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-idcard',
        template: __webpack_require__(/*! raw-loader!./idcard.component.html */ "./node_modules/raw-loader/index.js!./src/app/idcard/idcard.component.html"),
        styles: [__webpack_require__(/*! ./idcard.component.css */ "./src/app/idcard/idcard.component.css")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_data_service__WEBPACK_IMPORTED_MODULE_2__["DataService"]])
], IdcardComponent);



/***/ }),

/***/ "./src/app/idform/idform.component.css":
/*!*********************************************!*\
  !*** ./src/app/idform/idform.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/* to centralize the single id card */\r\n\r\n#outPopUp {\r\n  position: absolute;\r\n  width: 300px;\r\n  height: 200px;\r\n  z-index: 15;\r\n  top: 50%;\r\n  left: 50%;\r\n  margin: -100px 0 0 -150px;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaWRmb3JtL2lkZm9ybS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLHFDQUFxQzs7QUFFckM7RUFDRSxrQkFBa0I7RUFDbEIsWUFBWTtFQUNaLGFBQWE7RUFDYixXQUFXO0VBQ1gsUUFBUTtFQUNSLFNBQVM7RUFDVCx5QkFBeUI7QUFDM0IiLCJmaWxlIjoic3JjL2FwcC9pZGZvcm0vaWRmb3JtLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvKiB0byBjZW50cmFsaXplIHRoZSBzaW5nbGUgaWQgY2FyZCAqL1xyXG5cclxuI291dFBvcFVwIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgd2lkdGg6IDMwMHB4O1xyXG4gIGhlaWdodDogMjAwcHg7XHJcbiAgei1pbmRleDogMTU7XHJcbiAgdG9wOiA1MCU7XHJcbiAgbGVmdDogNTAlO1xyXG4gIG1hcmdpbjogLTEwMHB4IDAgMCAtMTUwcHg7XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/idform/idform.component.ts":
/*!********************************************!*\
  !*** ./src/app/idform/idform.component.ts ***!
  \********************************************/
/*! exports provided: IdformComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IdformComponent", function() { return IdformComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");

var IdformComponent_1;


let IdformComponent = IdformComponent_1 = class IdformComponent {
    constructor(fb) {
        this.fb = fb;
        this.message = "y";
        this.formattedMessage = "y";
        this.x = 0;
        this.allIdNos = [];
        this.allCards = [];
        this.totalIds = [];
        this.stringifiedallCards = "";
        this.showSingleCard = false;
        this.makeIdFormGroup = this.fb.group(IdformComponent_1.makeIdForm());
    }
    ngOnInit() {
    }
    makeNewId() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            yield this.allCards.push(this.makeIdFormGroup.value);
            yield localStorage.setItem("newid", JSON.stringify(this.allCards));
            yield this.x++;
            yield this.allIdNos.push(this.x);
            console.log("x", this.allIdNos);
            console.log("allcardss", this.allCards);
            console.log("newid4console", this.makeIdFormGroup.value);
            this.formValue = JSON.parse(localStorage.getItem("newid"));
            this.totalIds = this.allIdNos.slice(-1)[0];
        });
    }
    onChanges() {
        console.log("unformatedtttttt");
        this.makeIdFormGroup.get("fullname").valueChanges.subscribe(res => {
            this.me = JSON.stringify(this.makeIdFormGroup.value);
            localStorage.setItem("newName", JSON.stringify(this.makeIdFormGroup.value));
            console.log("unformated", res);
            this.formattedMessage = res;
            console.log("forformated", this.formattedMessage);
        }, error => { }, () => { });
    }
};
IdformComponent.makeIdForm = () => {
    return {
        fullname: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
        age: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
        bloodgroup: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(2)]),
        location: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])
    };
};
IdformComponent = IdformComponent_1 = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-idform",
        template: __webpack_require__(/*! raw-loader!./idform.component.html */ "./node_modules/raw-loader/index.js!./src/app/idform/idform.component.html"),
        styles: [__webpack_require__(/*! ./idform.component.css */ "./src/app/idform/idform.component.css")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]])
], IdformComponent);



/***/ })

}]);
//# sourceMappingURL=cards-cards-routing-module-es2015.js.map