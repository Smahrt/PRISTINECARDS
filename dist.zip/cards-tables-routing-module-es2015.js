(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["cards-tables-routing-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/idtable/idtable.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/idtable/idtable.component.html ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<div class=\"container pt-5\">\n<table class=\"table shadow\">\n    <thead class=\"thead-light\">\n      <tr>\n        <th scope=\"col\">#</th>\n        <th scope=\"col\">Full Name</th>\n        <th scope=\"col\">Age</th>\n        <th scope=\"col\">Blood Group</th>\n        <th scope=\"col\">Location</th>\n      </tr>\n    </thead>\n    <tbody>\n      <tr *ngFor=\"let table of parsedId; let i = index\">\n        <td>{{i+1}}</td>\n        <td>{{table?.fullname}}</td>\n        <td>{{table?.age}}</td>\n        <td>{{table?.bloodgroup}}</td>\n        <td>{{table?.location}}</td>\n      </tr>\n    </tbody>\n  </table>\n</div>\n\n"

/***/ }),

/***/ "./src/app/cards/tables-routing.module.ts":
/*!************************************************!*\
  !*** ./src/app/cards/tables-routing.module.ts ***!
  \************************************************/
/*! exports provided: TablesRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TablesRoutingModule", function() { return TablesRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../_helpers */ "./src/app/_helpers/index.ts");
/* harmony import */ var _idtable_idtable_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../idtable/idtable.component */ "./src/app/idtable/idtable.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");







const routes = [{ path: "", component: _idtable_idtable_component__WEBPACK_IMPORTED_MODULE_4__["IdtableComponent"], canActivate: [_helpers__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]] }];
let TablesRoutingModule = class TablesRoutingModule {
};
TablesRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ReactiveFormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)
        ],
        declarations: [_idtable_idtable_component__WEBPACK_IMPORTED_MODULE_4__["IdtableComponent"]],
        exports: [_idtable_idtable_component__WEBPACK_IMPORTED_MODULE_4__["IdtableComponent"]]
    })
], TablesRoutingModule);



/***/ }),

/***/ "./src/app/idtable/idtable.component.css":
/*!***********************************************!*\
  !*** ./src/app/idtable/idtable.component.css ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2lkdGFibGUvaWR0YWJsZS5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/idtable/idtable.component.ts":
/*!**********************************************!*\
  !*** ./src/app/idtable/idtable.component.ts ***!
  \**********************************************/
/*! exports provided: IdtableComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IdtableComponent", function() { return IdtableComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let IdtableComponent = class IdtableComponent {
    constructor() { }
    ngOnInit() {
        this.getAllIds();
        // localStorage.getItem("newid");
    }
    getAllIds() {
        JSON.parse(localStorage.getItem('current_user'));
        this.idTable = JSON.parse(localStorage.getItem("newid"));
        console.log('tableid', this.idTable);
        this.idTable.filter(idcard => {
            this.parsedId = JSON.parse(localStorage.getItem('newid'));
        });
        console.log('parsedId', this.parsedId);
        this.parsedId.filter(rrr => {
            console.log('parsedIdname', rrr.fullname);
        });
    }
};
IdtableComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-idtable",
        template: __webpack_require__(/*! raw-loader!./idtable.component.html */ "./node_modules/raw-loader/index.js!./src/app/idtable/idtable.component.html"),
        styles: [__webpack_require__(/*! ./idtable.component.css */ "./src/app/idtable/idtable.component.css")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], IdtableComponent);

// response.filter(auction => {
//   // if(auction.productObject[0]=='{'){
//     auction.productObject = JSON.parse(auction.productObject);
//   // }
//   return (auction.startAuction);
// });


/***/ })

}]);
//# sourceMappingURL=cards-tables-routing-module-es2015.js.map